module.exports = (bot, chatId) => {
    bot.sendMessage(chatId, 'زبان مورد نظر خود را انتخاب کنید.');
};