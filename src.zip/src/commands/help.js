module.exports = (bot, chatId) => {
    bot.sendMessage(chatId, 'این راهنمای استفاده از ربات است.');
};